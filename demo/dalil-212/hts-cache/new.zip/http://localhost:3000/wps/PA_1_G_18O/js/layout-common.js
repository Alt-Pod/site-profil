<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Action Controller: Exception caught</title>
  <style>
    body {
      background-color: #FAFAFA;
      color: #333;
      margin: 0px;
    }

    body, p, ol, ul, td {
      font-family: helvetica, verdana, arial, sans-serif;
      font-size:   13px;
      line-height: 18px;
    }

    pre {
      font-size: 11px;
      white-space: pre-wrap;
    }

    pre.box {
      border: 1px solid #EEE;
      padding: 10px;
      margin: 0px;
      width: 958px;
    }

    header {
      color: #F0F0F0;
      background: #C52F24;
      padding: 0.5em 1.5em;
    }

    h1 {
      margin: 0.2em 0;
      line-height: 1.1em;
      font-size: 2em;
    }

    h2 {
      color: #C52F24;
      line-height: 25px;
    }

    .details {
      border: 1px solid #D0D0D0;
      border-radius: 4px;
      margin: 1em 0px;
      display: block;
      width: 978px;
    }

    .summary {
      padding: 8px 15px;
      border-bottom: 1px solid #D0D0D0;
      display: block;
    }

    .details pre {
      margin: 5px;
      border: none;
    }

    #container {
      box-sizing: border-box;
      width: 100%;
      padding: 0 1.5em;
    }

    .source * {
      margin: 0px;
      padding: 0px;
    }

    .source {
      border: 1px solid #D9D9D9;
      background: #ECECEC;
      width: 978px;
    }

    .source pre {
      padding: 10px 0px;
      border: none;
    }

    .source .data {
      font-size: 80%;
      overflow: auto;
      background-color: #FFF;
    }

    .info {
      padding: 0.5em;
    }

    .source .data .line_numbers {
      background-color: #ECECEC;
      color: #AAA;
      padding: 1em .5em;
      border-right: 1px solid #DDD;
      text-align: right;
    }

    .line {
      padding-left: 10px;
    }

    .line:hover {
      background-color: #F6F6F6;
    }

    .line.active {
      background-color: #FFCCCC;
    }

    .hidden {
      display: none;
    }

    a { color: #980905; }
    a:visited { color: #666; }
    a.trace-frames { color: #666; }
    a:hover { color: #C52F24; }
    a.trace-frames.selected { color: #C52F24 }

      #route_table {
    margin: 0 auto 0;
    border-collapse: collapse;
  }

  #route_table thead tr {
    border-bottom: 2px solid #ddd;
  }

  #route_table thead tr.bottom {
    border-bottom: none;
  }

  #route_table thead tr.bottom th {
    padding: 10px 0;
    line-height: 15px;
  }

  #route_table tbody tr {
    border-bottom: 1px solid #ddd;
  }

  #route_table tbody tr:nth-child(odd) {
    background: #f2f2f2;
  }

  #route_table tbody.exact_matches,
  #route_table tbody.fuzzy_matches {
    background-color: LightGoldenRodYellow;
    border-bottom: solid 2px SlateGrey;
  }

  #route_table tbody.exact_matches tr,
  #route_table tbody.fuzzy_matches tr {
    background: none;
    border-bottom: none;
  }

  #route_table td {
    padding: 4px 30px;
  }

  #path_search {
    width: 80%;
    font-size: inherit;
  }

  </style>

  <script>
    var toggle = function(id) {
      var s = document.getElementById(id).style;
      s.display = s.display == 'none' ? 'block' : 'none';
      return false;
    }
    var show = function(id) {
      document.getElementById(id).style.display = 'block';
    }
    var hide = function(id) {
      document.getElementById(id).style.display = 'none';
    }
    var toggleTrace = function() {
      return toggle('blame_trace');
    }
    var toggleSessionDump = function() {
      return toggle('session_dump');
    }
    var toggleEnvDump = function() {
      return toggle('env_dump');
    }
  </script>
</head>
<body>

<header>
  <h1>Routing Error</h1>
</header>
<div id="container">
  <h2>No route matches [GET] &quot;/wps/PA_1_G_18O/js/layout-common.js&quot;</h2>

  
<p><code>Rails.root: /home/michael/RubymineProjects/dalil212_exchange</code></p>

<div id="traces">
    <a href="#" onclick="hide(&#39;Framework-Trace&#39;);hide(&#39;Full-Trace&#39;);show(&#39;Application-Trace&#39;);; return false;">Application Trace</a> |
    <a href="#" onclick="hide(&#39;Application-Trace&#39;);hide(&#39;Full-Trace&#39;);show(&#39;Framework-Trace&#39;);; return false;">Framework Trace</a> |
    <a href="#" onclick="hide(&#39;Application-Trace&#39;);hide(&#39;Framework-Trace&#39;);show(&#39;Full-Trace&#39;);; return false;">Full Trace</a> 

    <div id="Application-Trace" style="display: block;">
      <pre><code></code></pre>
    </div>
    <div id="Framework-Trace" style="display: none;">
      <pre><code><a class="trace-frames" data-frame-id="0" href="#">vendor/cache/ruby/2.1.0/gems/actionpack-4.2.0.beta1/lib/action_dispatch/middleware/debug_exceptions.rb:21:in `call&#39;</a><br><a class="trace-frames" data-frame-id="1" href="#">vendor/cache/ruby/2.1.0/gems/actionpack-4.2.0.beta1/lib/action_dispatch/middleware/show_exceptions.rb:30:in `call&#39;</a><br><a class="trace-frames" data-frame-id="2" href="#">vendor/cache/ruby/2.1.0/gems/railties-4.2.0.beta1/lib/rails/rack/logger.rb:38:in `call_app&#39;</a><br><a class="trace-frames" data-frame-id="3" href="#">vendor/cache/ruby/2.1.0/gems/railties-4.2.0.beta1/lib/rails/rack/logger.rb:20:in `block in call&#39;</a><br><a class="trace-frames" data-frame-id="4" href="#">vendor/cache/ruby/2.1.0/gems/activesupport-4.2.0.beta1/lib/active_support/tagged_logging.rb:68:in `block in tagged&#39;</a><br><a class="trace-frames" data-frame-id="5" href="#">vendor/cache/ruby/2.1.0/gems/activesupport-4.2.0.beta1/lib/active_support/tagged_logging.rb:26:in `tagged&#39;</a><br><a class="trace-frames" data-frame-id="6" href="#">vendor/cache/ruby/2.1.0/gems/activesupport-4.2.0.beta1/lib/active_support/tagged_logging.rb:68:in `tagged&#39;</a><br><a class="trace-frames" data-frame-id="7" href="#">vendor/cache/ruby/2.1.0/gems/railties-4.2.0.beta1/lib/rails/rack/logger.rb:20:in `call&#39;</a><br><a class="trace-frames" data-frame-id="8" href="#">vendor/cache/ruby/2.1.0/gems/quiet_assets-1.0.3/lib/quiet_assets.rb:23:in `call_with_quiet_assets&#39;</a><br><a class="trace-frames" data-frame-id="9" href="#">vendor/cache/ruby/2.1.0/gems/actionpack-4.2.0.beta1/lib/action_dispatch/middleware/request_id.rb:21:in `call&#39;</a><br><a class="trace-frames" data-frame-id="10" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/methodoverride.rb:22:in `call&#39;</a><br><a class="trace-frames" data-frame-id="11" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/runtime.rb:17:in `call&#39;</a><br><a class="trace-frames" data-frame-id="12" href="#">vendor/cache/ruby/2.1.0/gems/activesupport-4.2.0.beta1/lib/active_support/cache/strategy/local_cache_middleware.rb:28:in `call&#39;</a><br><a class="trace-frames" data-frame-id="13" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/lock.rb:17:in `call&#39;</a><br><a class="trace-frames" data-frame-id="14" href="#">vendor/cache/ruby/2.1.0/gems/actionpack-4.2.0.beta1/lib/action_dispatch/middleware/static.rb:83:in `call&#39;</a><br><a class="trace-frames" data-frame-id="15" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/sendfile.rb:113:in `call&#39;</a><br><a class="trace-frames" data-frame-id="16" href="#">vendor/cache/ruby/2.1.0/gems/railties-4.2.0.beta1/lib/rails/engine.rb:514:in `call&#39;</a><br><a class="trace-frames" data-frame-id="17" href="#">vendor/cache/ruby/2.1.0/gems/railties-4.2.0.beta1/lib/rails/application.rb:161:in `call&#39;</a><br><a class="trace-frames" data-frame-id="18" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/tempfile_reaper.rb:15:in `call&#39;</a><br><a class="trace-frames" data-frame-id="19" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/lint.rb:49:in `_call&#39;</a><br><a class="trace-frames" data-frame-id="20" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/lint.rb:37:in `call&#39;</a><br><a class="trace-frames" data-frame-id="21" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/showexceptions.rb:24:in `call&#39;</a><br><a class="trace-frames" data-frame-id="22" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/commonlogger.rb:33:in `call&#39;</a><br><a class="trace-frames" data-frame-id="23" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/chunked.rb:54:in `call&#39;</a><br><a class="trace-frames" data-frame-id="24" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/content_length.rb:15:in `call&#39;</a><br><a class="trace-frames" data-frame-id="25" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/handler/webrick.rb:89:in `service&#39;</a><br><a class="trace-frames" data-frame-id="26" href="#">/home/michael/.rbenv/versions/2.1.2/lib/ruby/2.1.0/webrick/httpserver.rb:138:in `service&#39;</a><br><a class="trace-frames" data-frame-id="27" href="#">/home/michael/.rbenv/versions/2.1.2/lib/ruby/2.1.0/webrick/httpserver.rb:94:in `run&#39;</a><br><a class="trace-frames" data-frame-id="28" href="#">/home/michael/.rbenv/versions/2.1.2/lib/ruby/2.1.0/webrick/server.rb:295:in `block in start_thread&#39;</a><br></code></pre>
    </div>
    <div id="Full-Trace" style="display: none;">
      <pre><code><a class="trace-frames" data-frame-id="0" href="#">vendor/cache/ruby/2.1.0/gems/actionpack-4.2.0.beta1/lib/action_dispatch/middleware/debug_exceptions.rb:21:in `call&#39;</a><br><a class="trace-frames" data-frame-id="1" href="#">vendor/cache/ruby/2.1.0/gems/actionpack-4.2.0.beta1/lib/action_dispatch/middleware/show_exceptions.rb:30:in `call&#39;</a><br><a class="trace-frames" data-frame-id="2" href="#">vendor/cache/ruby/2.1.0/gems/railties-4.2.0.beta1/lib/rails/rack/logger.rb:38:in `call_app&#39;</a><br><a class="trace-frames" data-frame-id="3" href="#">vendor/cache/ruby/2.1.0/gems/railties-4.2.0.beta1/lib/rails/rack/logger.rb:20:in `block in call&#39;</a><br><a class="trace-frames" data-frame-id="4" href="#">vendor/cache/ruby/2.1.0/gems/activesupport-4.2.0.beta1/lib/active_support/tagged_logging.rb:68:in `block in tagged&#39;</a><br><a class="trace-frames" data-frame-id="5" href="#">vendor/cache/ruby/2.1.0/gems/activesupport-4.2.0.beta1/lib/active_support/tagged_logging.rb:26:in `tagged&#39;</a><br><a class="trace-frames" data-frame-id="6" href="#">vendor/cache/ruby/2.1.0/gems/activesupport-4.2.0.beta1/lib/active_support/tagged_logging.rb:68:in `tagged&#39;</a><br><a class="trace-frames" data-frame-id="7" href="#">vendor/cache/ruby/2.1.0/gems/railties-4.2.0.beta1/lib/rails/rack/logger.rb:20:in `call&#39;</a><br><a class="trace-frames" data-frame-id="8" href="#">vendor/cache/ruby/2.1.0/gems/quiet_assets-1.0.3/lib/quiet_assets.rb:23:in `call_with_quiet_assets&#39;</a><br><a class="trace-frames" data-frame-id="9" href="#">vendor/cache/ruby/2.1.0/gems/actionpack-4.2.0.beta1/lib/action_dispatch/middleware/request_id.rb:21:in `call&#39;</a><br><a class="trace-frames" data-frame-id="10" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/methodoverride.rb:22:in `call&#39;</a><br><a class="trace-frames" data-frame-id="11" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/runtime.rb:17:in `call&#39;</a><br><a class="trace-frames" data-frame-id="12" href="#">vendor/cache/ruby/2.1.0/gems/activesupport-4.2.0.beta1/lib/active_support/cache/strategy/local_cache_middleware.rb:28:in `call&#39;</a><br><a class="trace-frames" data-frame-id="13" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/lock.rb:17:in `call&#39;</a><br><a class="trace-frames" data-frame-id="14" href="#">vendor/cache/ruby/2.1.0/gems/actionpack-4.2.0.beta1/lib/action_dispatch/middleware/static.rb:83:in `call&#39;</a><br><a class="trace-frames" data-frame-id="15" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/sendfile.rb:113:in `call&#39;</a><br><a class="trace-frames" data-frame-id="16" href="#">vendor/cache/ruby/2.1.0/gems/railties-4.2.0.beta1/lib/rails/engine.rb:514:in `call&#39;</a><br><a class="trace-frames" data-frame-id="17" href="#">vendor/cache/ruby/2.1.0/gems/railties-4.2.0.beta1/lib/rails/application.rb:161:in `call&#39;</a><br><a class="trace-frames" data-frame-id="18" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/tempfile_reaper.rb:15:in `call&#39;</a><br><a class="trace-frames" data-frame-id="19" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/lint.rb:49:in `_call&#39;</a><br><a class="trace-frames" data-frame-id="20" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/lint.rb:37:in `call&#39;</a><br><a class="trace-frames" data-frame-id="21" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/showexceptions.rb:24:in `call&#39;</a><br><a class="trace-frames" data-frame-id="22" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/commonlogger.rb:33:in `call&#39;</a><br><a class="trace-frames" data-frame-id="23" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/chunked.rb:54:in `call&#39;</a><br><a class="trace-frames" data-frame-id="24" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/content_length.rb:15:in `call&#39;</a><br><a class="trace-frames" data-frame-id="25" href="#">vendor/cache/ruby/2.1.0/gems/rack-1.6.0.beta/lib/rack/handler/webrick.rb:89:in `service&#39;</a><br><a class="trace-frames" data-frame-id="26" href="#">/home/michael/.rbenv/versions/2.1.2/lib/ruby/2.1.0/webrick/httpserver.rb:138:in `service&#39;</a><br><a class="trace-frames" data-frame-id="27" href="#">/home/michael/.rbenv/versions/2.1.2/lib/ruby/2.1.0/webrick/httpserver.rb:94:in `run&#39;</a><br><a class="trace-frames" data-frame-id="28" href="#">/home/michael/.rbenv/versions/2.1.2/lib/ruby/2.1.0/webrick/server.rb:295:in `block in start_thread&#39;</a><br></code></pre>
    </div>

  <script type="text/javascript">
    var traceFrames = document.getElementsByClassName('trace-frames');
    var selectedFrame, currentSource = document.getElementById('frame-source-0');

    // Add click listeners for all stack frames
    for (var i = 0; i < traceFrames.length; i++) {
      traceFrames[i].addEventListener('click', function(e) {
        e.preventDefault();
        var target = e.target;
        var frame_id = target.dataset.frameId;

        if (selectedFrame) {
          selectedFrame.className = selectedFrame.className.replace("selected", "");
        }

        target.className += " selected";
        selectedFrame = target;

        // Change the extracted source code
        changeSourceExtract(frame_id);
      });

      function changeSourceExtract(frame_id) {
        var el = document.getElementById('frame-source-' + frame_id);
        if (currentSource && el) {
          currentSource.className += " hidden";
          el.className = el.className.replace(" hidden", "");
          currentSource = el;
        }
      }
    }
  </script>
</div>


    <h2>
      Routes
    </h2>

    <p>
      Routes match in priority from top to bottom
    </p>

    
<table id='route_table' class='route_table'>
  <thead>
    <tr>
      <th>Helper</th>
      <th>HTTP Verb</th>
      <th>Path</th>
      <th>Controller#Action</th>
    </tr>
    <tr class='bottom'>
      <th>
        <a data-route-helper="_path" href="#" title="Returns a relative path (without the http or domain)">Path</a> /
        <a data-route-helper="_url" href="#" title="Returns an absolute url (with the http and domain)">Url</a>
      </th>
      <th>
      </th>
      <th>
        <input id="search" name="path[]" placeholder="" type="search" />
      </th>
      <th>
      </th>
    </tr>
  </thead>
  <tbody class='exact_matches' id='exact_matches'>
  </tbody>
  <tbody class='fuzzy_matches' id='fuzzy_matches'>
  </tbody>
  <tbody>
    <tr class='route_row' data-helper='path'>
  <td data-route-name='p_home'>
      p_home<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/home(.:format)' data-regexp='^\/p\/home(?:\.([^\/.?]+))?$'>
    /p/home(.:format)
  </td>
  <td data-route-reqs='p#home'>
    p#home
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_home1'>
      p_home1<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/home1(.:format)' data-regexp='^\/p\/home1(?:\.([^\/.?]+))?$'>
    /p/home1(.:format)
  </td>
  <td data-route-reqs='p#home1'>
    p#home1
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_custom_home_1'>
      p_custom_home_1<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/custom_home_1(.:format)' data-regexp='^\/p\/custom_home_1(?:\.([^\/.?]+))?$'>
    /p/custom_home_1(.:format)
  </td>
  <td data-route-reqs='p#custom_home_1'>
    p#custom_home_1
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_custom_home_2'>
      p_custom_home_2<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/custom_home_2(.:format)' data-regexp='^\/p\/custom_home_2(?:\.([^\/.?]+))?$'>
    /p/custom_home_2(.:format)
  </td>
  <td data-route-reqs='p#custom_home_2'>
    p#custom_home_2
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_custom_home_3'>
      p_custom_home_3<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/custom_home_3(.:format)' data-regexp='^\/p\/custom_home_3(?:\.([^\/.?]+))?$'>
    /p/custom_home_3(.:format)
  </td>
  <td data-route-reqs='p#custom_home_3'>
    p#custom_home_3
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_custom_home_4'>
      p_custom_home_4<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/custom_home_4(.:format)' data-regexp='^\/p\/custom_home_4(?:\.([^\/.?]+))?$'>
    /p/custom_home_4(.:format)
  </td>
  <td data-route-reqs='p#custom_home_4'>
    p#custom_home_4
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_custom_home_5'>
      p_custom_home_5<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/custom_home_5(.:format)' data-regexp='^\/p\/custom_home_5(?:\.([^\/.?]+))?$'>
    /p/custom_home_5(.:format)
  </td>
  <td data-route-reqs='p#custom_home_5'>
    p#custom_home_5
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_home_immo'>
      p_home_immo<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/home_immo(.:format)' data-regexp='^\/p\/home_immo(?:\.([^\/.?]+))?$'>
    /p/home_immo(.:format)
  </td>
  <td data-route-reqs='p#home_immo'>
    p#home_immo
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_spa'>
      p_spa<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/spa(.:format)' data-regexp='^\/p\/spa(?:\.([^\/.?]+))?$'>
    /p/spa(.:format)
  </td>
  <td data-route-reqs='p#spa'>
    p#spa
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_cosmetic'>
      p_cosmetic<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/cosmetic(.:format)' data-regexp='^\/p\/cosmetic(?:\.([^\/.?]+))?$'>
    /p/cosmetic(.:format)
  </td>
  <td data-route-reqs='p#cosmetic'>
    p#cosmetic
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_home_dalil'>
      p_home_dalil<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/home_dalil(.:format)' data-regexp='^\/p\/home_dalil(?:\.([^\/.?]+))?$'>
    /p/home_dalil(.:format)
  </td>
  <td data-route-reqs='p#home_dalil'>
    p#home_dalil
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_home_dalil_2'>
      p_home_dalil_2<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/home_dalil_2(.:format)' data-regexp='^\/p\/home_dalil_2(?:\.([^\/.?]+))?$'>
    /p/home_dalil_2(.:format)
  </td>
  <td data-route-reqs='p#home_dalil_2'>
    p#home_dalil_2
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_loan'>
      p_loan<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/loan(.:format)' data-regexp='^\/p\/loan(?:\.([^\/.?]+))?$'>
    /p/loan(.:format)
  </td>
  <td data-route-reqs='p#loan'>
    p#loan
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_pie_timer'>
      p_pie_timer<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/pie_timer(.:format)' data-regexp='^\/p\/pie_timer(?:\.([^\/.?]+))?$'>
    /p/pie_timer(.:format)
  </td>
  <td data-route-reqs='p#pie_timer'>
    p#pie_timer
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_search_result'>
      p_search_result<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/search_result(.:format)' data-regexp='^\/p\/search_result(?:\.([^\/.?]+))?$'>
    /p/search_result(.:format)
  </td>
  <td data-route-reqs='p#search_result'>
    p#search_result
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_profil'>
      p_profil<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/profil(.:format)' data-regexp='^\/p\/profil(?:\.([^\/.?]+))?$'>
    /p/profil(.:format)
  </td>
  <td data-route-reqs='p#profil'>
    p#profil
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_profil1'>
      p_profil1<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/profil1(.:format)' data-regexp='^\/p\/profil1(?:\.([^\/.?]+))?$'>
    /p/profil1(.:format)
  </td>
  <td data-route-reqs='p#profil1'>
    p#profil1
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='p_index'>
      p_index<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/p/index(.:format)' data-regexp='^\/p\/index(?:\.([^\/.?]+))?$'>
    /p/index(.:format)
  </td>
  <td data-route-reqs='p#index'>
    p#index
  </td>
</tr>
<tr class='route_row' data-helper='path'>
  <td data-route-name='root'>
      root<span class='helper'>_path</span>
  </td>
  <td data-route-verb='GET'>
    GET
  </td>
  <td data-route-path='/' data-regexp='^\/$'>
    /
  </td>
  <td data-route-reqs='p#index'>
    p#index
  </td>
</tr>

  </tbody>
</table>

<script type='text/javascript'>
  // Iterates each element through a function
  function each(elems, func) {
    if (!elems instanceof Array) { elems = [elems]; }
    for (var i = 0, len = elems.length; i < len; i++) {
      func(elems[i]);
    }
  }

  // Sets innerHTML for an element
  function setContent(elem, text) {
    elem.innerHTML = text;
  }

  // Enables path search functionality
  function setupMatchPaths() {
    // Check if the user input (sanitized as a path) matches the regexp data attribute
    function checkExactMatch(section, elem, value) {
      var string = sanitizePath(value),
          regexp = elem.getAttribute("data-regexp");

      showMatch(string, regexp, section, elem);
    }

    // Check if the route path data attribute contains the user input
    function checkFuzzyMatch(section, elem, value) {
      var string = elem.getAttribute("data-route-path"),
          regexp = value;

      showMatch(string, regexp, section, elem);
    }

    // Display the parent <tr> element in the appropriate section when there's a match
    function showMatch(string, regexp, section, elem) {
      if(string.match(RegExp(regexp))) {
        section.appendChild(elem.parentNode.cloneNode(true));
      }
    }

    // Check if there are any matched results in a section
    function checkNoMatch(section, defaultText, noMatchText) {
      if (section.innerHTML === defaultText) {
        setContent(section, defaultText + noMatchText);
      }
    }

    // Ensure path always starts with a slash "/" and remove params or fragments
    function sanitizePath(path) {
      var path = path.charAt(0) == '/' ? path : "/" + path;
      return path.replace(/\#.*|\?.*/, '');
    }

    var regexpElems     = document.querySelectorAll('#route_table [data-regexp]'),
        searchElem      = document.querySelector('#search'),
        exactMatches    = document.querySelector('#exact_matches'),
        fuzzyMatches    = document.querySelector('#fuzzy_matches');

    // Remove matches when no search value is present
    searchElem.onblur = function(e) {
      if (searchElem.value === "") {
        setContent(exactMatches, "");
        setContent(fuzzyMatches, "");
      }
    }

    // On key press perform a search for matching paths
    searchElem.onkeyup = function(e){
      var userInput         = searchElem.value,
          defaultExactMatch = '<tr><th colspan="4">Paths Matching (' + escape(sanitizePath(userInput)) +'):</th></tr>',
          defaultFuzzyMatch = '<tr><th colspan="4">Paths Containing (' + escape(userInput) +'):</th></tr>',
          noExactMatch      = '<tr><th colspan="4">No Exact Matches Found</th></tr>',
          noFuzzyMatch      = '<tr><th colspan="4">No Fuzzy Matches Found</th></tr>';

      // Clear out results section
      setContent(exactMatches, defaultExactMatch);
      setContent(fuzzyMatches, defaultFuzzyMatch);

      // Display exact matches and fuzzy matches
      each(regexpElems, function(elem) {
        checkExactMatch(exactMatches, elem, userInput);
        checkFuzzyMatch(fuzzyMatches, elem, userInput);
      })

      // Display 'No Matches' message when no matches are found
      checkNoMatch(exactMatches, defaultExactMatch, noExactMatch);
      checkNoMatch(fuzzyMatches, defaultFuzzyMatch, noFuzzyMatch);
    }
  }

  // Enables functionality to toggle between `_path` and `_url` helper suffixes
  function setupRouteToggleHelperLinks() {

    // Sets content for each element
    function setValOn(elems, val) {
      each(elems, function(elem) {
        setContent(elem, val);
      });
    }

    // Sets onClick event for each element
    function onClick(elems, func) {
      each(elems, function(elem) {
        elem.onclick = func;
      });
    }

    var toggleLinks = document.querySelectorAll('#route_table [data-route-helper]');
    onClick(toggleLinks, function(){
      var helperTxt   = this.getAttribute("data-route-helper"),
          helperElems = document.querySelectorAll('[data-route-name] span.helper');

      setValOn(helperElems, helperTxt);
    });
  }

  setupMatchPaths();
  setupRouteToggleHelperLinks();
</script>

</div>


</body>
</html>
